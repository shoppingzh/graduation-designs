#include "led.h"
#include "delay.h"
#include "sys.h"
#include "stdio.h"
#include "fpm10a.h"
#include "lcd.h"
#include "touch.h"


   TypeDef_FR test={0xff01,0xffffffff,0x01,0x7,{0x04,0x72,0x83,0x99,0xa5},0x0};
   unsigned char test_table[]="                             "; 
	 unsigned char temp_x,temp_y;
   unsigned char iii=0;
	 unsigned char dec[256] = {0};
   u32 bmp_x=0,bmp_y=0;
   u32 cacu = 0;

  
 int main(void)
 {	

   delay_init();	    	 //��ʱ������ʼ��	  
	 LED_Init();		  	//��ʼ����LED���ӵ�Ӳ���ӿ�
   SoftInitrrupt_Init();
   USART1_INIT(115200);
   memset(&PriRecBffer,0,sizeof(TypeDef_RecPacket)); //�����ʼ��
   LCD_Init();
   TP_Init();
 //  delay_ms(1000);
    
    POINT_COLOR = 0x00;
    LCD_DrawRectangle(0,289,50,319);
    LCD_DrawRectangle(60,289,110,319);
    LCD_DrawRectangle(120,289,170,319);
    LCD_DrawRectangle(180,289,230,319);
   
    LCD_DrawRectangle(0,258,50,288);
    LCD_DrawRectangle(60,258,110,288);
    LCD_DrawRectangle(120,258,170,288);
    LCD_DrawRectangle(180,258,230,288);
   
    LCD_DrawRectangle(0,227,50,257);
    LCD_DrawRectangle(60,227,110,257);
    LCD_DrawRectangle(120,227,170,257);
    LCD_DrawRectangle(180,227,230,257);
    POINT_COLOR = RED;
//    LCD_DrawRectangle(0,289,49,319);
//    LCD_DrawRectangle(0,289,49,319);
//    LCD_DrawRectangle(0,289,49,319);
//    LCD_DrawRectangle(0,289,49,319);
   //FPM_SendPacket(&GenImg);
 //  LCD_ShowString(0,80,240,16,16,(u8*)"I am test the lcd!!!");
   //FPM_SendPacket(&SetSysPara);
 printf("0x%x\r\n",Gray2RGB(15));

 LED0=1;
      
      sprintf((char*)test_table,"Header 0x%x ",PriRecBffer.Packge.Start);
      LCD_ShowString(0,0,240,16,16,(u8*)test_table);
      sprintf((char*)test_table,"Addre 0x%x ",PriRecBffer.Packge.Addre);
      LCD_ShowString(0,16,240,16,16,(u8*)test_table);
      sprintf((char*)test_table,"PID  0x%x ",PriRecBffer.Packge.PID);
      LCD_ShowString(0,32,240,16,16,(u8*)test_table);
      sprintf((char*)test_table,"Length 0x%x ",PriRecBffer.Packge.Length);
      LCD_ShowString(0,48,240,16,16,(u8*)test_table);
      sprintf((char*)test_table,"Command 0x%x ",PriRecBffer.Packge.Data[0]);
      LCD_ShowString(0,64,240,16,16,(u8*)test_table);
      sprintf((char*)test_table,"SUM 0x%x ",PriRecBffer.Packge.SUM);
      LCD_ShowString(0,80,240,16,16,(u8*)test_table);
      
      sprintf((char*)test_table,"SIZE OF %d Byte ",sizeof(TypeDef_RecPacket));
      LCD_ShowString(0,96,240,16,16,(u8*)test_table);
      FingerPrint_UpdaPara();
 #ifdef UsePrintf
      printf("StateRegister      0x%04d\r\n",FRParameter.StateRegister);
      printf("SensorType         0x%04d\r\n",FRParameter.SensorType);
      printf("DataBaseSize       %04d\r\n",FRParameter.DataBaseSize);
      printf("SecurityRank       %04d\r\n",FRParameter.SecurityRank);
      printf("DataPacketSize     %04d\r\n",FRParameter.DataPacketSize);
      printf("Baudrate           %06d\r\n",FRParameter.Baudrate);
      printf("ValidTempleteNum   %04d\r\n",FRParameter.TempleteNum);
      printf("DeviceAddress      0x%08x\r\n",FRParameter.DeviceAddress);
#endif      
	while(1)
	{
    /*����ɨ��*/
    TP_Scan(0);
    if(tp_dev.sta&TP_PRES_DOWN)
    {
      temp_x = tp_dev.x[0]/60;//x�ֱ���
      temp_y = (319-tp_dev.y[0])/30;//y�ֱ���
    
    switch(temp_x)
    {
      case 0:
        switch(temp_y)
        {
          case 0:
            
           LCD_ShowString(200,0,240,16,16,"key1 ");
           FRParameter.TempleteNum++;
           FingerPrint_record_a_template(FRParameter.TempleteNum);
           FingerPrint_UpdaImage();
           //printf("ValidTempleteNum  0x%08x\r\n",FRParameter.TempleteNum);
            break;
          case 1:
           LCD_ShowString(200,0,240,16,16,"key5 ");
					/*��ȡԭʼͼ��*/
					FingerPrint_UpdaImage();
            break;
          case 2:
           LCD_ShowString(200,0,240,16,16,"key9 ");
           FPM_SendPacket(&SetSysPara);
            break;
        }
        delay_ms(500);
        break;
      case 1:
        switch(temp_y)
        {
          case 0:
            LCD_ShowString(200,0,240,16,16,"key2 ");
            FingerPrint_Search();
            break;
          case 1:
            LCD_ShowString(200,0,240,16,16,"key6 ");
            FPM_SendPacket(&VfyPwd);
            while(!PriRecBffer.DataRecCom); 
            PriRecBffer.DataRecCom = 0;
            GetCurPacket_ACK(&PriRecBffer.Packge);
            break;
          case 2:
            LCD_ShowString(200,0,240,16,16,"key10");
            break;
        }
        delay_ms(500);
        break;
      case 2:
        switch(temp_y)
        {
          case 0:
            LCD_ShowString(200,0,240,16,16,"key3 ");
            FPM_SendPacket(&Empty);
            break;
          case 1:
            LCD_ShowString(200,0,240,16,16,"key7 ");
            break;
          case 2:
            LCD_ShowString(200,0,240,16,16,"key11");
            break;
        }
        delay_ms(500);
        break;
      case 3:
        switch(temp_y)
        {
          case 0: 
            LCD_ShowString(200,0,240,16,16,"key4 ");
          FPM_SendPacket(&SetPwd);
          while(!PriRecBffer.DataRecCom);
          
          PriRecBffer.DataRecCom = 0;
           GetCurPacket_ACK(&PriRecBffer.Packge);
            break;
          case 1:
            LCD_ShowString(200,0,240,16,16,"key8 ");//
            break;
          case 2:
            LCD_ShowString(200,0,240,16,16,"key12");//
            break;
        }
        delay_ms(500);
        break;
     }
    }
    
#ifdef  UseBMPFunc  //ʹ��BMP����
    
    if(PriRecBffer.Status_BMP & Data_BMP_Cmp)
      {
        PriRecBffer.Status_BMP &= (~Data_BMP_Cmp);//�����־
         LCD_Set_Window(0,0,240,288);
       #ifdef UsePrintf
        printf("0x%x \r\n",(PriRecBffer.Status_BMP & 0x0fffffff));
       #endif
        LCD_WriteRAM_Prepare();     		//��ʼд��GRAM	 
        for(bmp_y=0;bmp_y<288;bmp_y++)//266��
        {   
          for(bmp_x=0;bmp_x<120;bmp_x++)
          {
            POINT_COLOR = Gray2RGB((((PriRecBffer.BMP_128x288[bmp_y*128+bmp_x]>>4)&0x0f)));
            LCD->LCD_RAM=POINT_COLOR;
            POINT_COLOR = Gray2RGB(((PriRecBffer.BMP_128x288[bmp_y*128+bmp_x]&0x0f)));
            LCD->LCD_RAM=POINT_COLOR;
            
           // printf("%02X ",PriRecBffer.BMP_128x288[bmp_y*128+bmp_x]);
          }
           //printf("\r\n");
        }
      }
#endif
     // printf("what happend \r\n");
    if(PriRecBffer.DataRecCom){
      PriRecBffer.DataRecCom=0;
     /* 
      sprintf((char*)test_table,"Header 0x%x ",PriRecBffer.Packge.Start);
      LCD_ShowString(0,0,240,16,16,(u8*)test_table);
      sprintf((char*)test_table,"Addre 0x%x ",PriRecBffer.Packge.Addre);
      LCD_ShowString(0,16,240,16,16,(u8*)test_table);
      sprintf((char*)test_table,"PID  0x%x ",PriRecBffer.Packge.PID);
      LCD_ShowString(0,32,240,16,16,(u8*)test_table);
      sprintf((char*)test_table,"Length 0x%x ",PriRecBffer.Packge.Length);
      LCD_ShowString(0,48,240,16,16,(u8*)test_table);
      sprintf((char*)test_table,"Command 0x%x ",PriRecBffer.Packge.Data[0]);
      LCD_ShowString(0,64,240,16,16,(u8*)test_table);
      sprintf((char*)test_table,"SUM 0x%x ",PriRecBffer.Packge.SUM);
      LCD_ShowString(0,80,240,16,16,(u8*)test_table);
      GetCurPacket_ACK(&PriRecBffer.Packge);
      */
//      printf("0x%e,0x%e,0x%e,0x%e,0x%e,0x%e,0x%e,0x%e, ")
//      for(iii=0;iii<RF_Rec_Packet.Length-2;iii++)
//      printf("0x%x ",RF_Rec_Packet.Data[iii]);
//      printf("\r\n");
      /*
      printf("Header 0x%x \r\n",PriRecBffer.Packge.Start);
      
      printf("Addre 0x%x \r\n",PriRecBffer.Packge.Addre);
      printf("PID  0x%x \r\n",PriRecBffer.Packge.PID);
      printf("Length %d \r\n",PriRecBffer.Packge.Length);
      printf("Code   0x%x \r\n",PriRecBffer.Packge.Data[0]);
      printf("SUM 0x%x \r\n\r\n\r\n",PriRecBffer.Packge.SUM);
     */
			//Str_Copy(BMP+bmp_y*128,RF_Rec_Packet.Data,128);
    }
	}
 }
 



